import subprocess

from config import PROJECT_ROOT_PATH, VIRTUALENV_PYTHON_PATH
from embedding import SkipGramModel


class Node2vecModel(SkipGramModel):

    def __init__(self, name, dimension, window_size, iter, number_walks, walk_length, p, q, directed, weighted,
                 input_filename, output_embedding_filename, workers):
        super(Node2vecModel, self).__init__(name, dimension, window_size, iter, output_embedding_filename, workers)
        self.set_walk_parameters(number_walks, walk_length, p, q, directed, weighted)
        self.set_input(input_filename)

    def set_walk_parameters(self, number_walks, walk_length, p, q, directed, weighted):
        self.number_walks = number_walks
        self.walk_length = walk_length
        self.directed = directed
        self.weighted = weighted
        self.p = p
        self.q = q

    def set_input(self, input_filename):
        self.input = input_filename

    def embedding(self):
        command = VIRTUALENV_PYTHON_PATH + " " + PROJECT_ROOT_PATH + "model/node2vec/src/main.py --input " + self.input + " --output " + self.output_embedding_filename + " --dimensions " + str(
            self.dimension) + " --walk-length " + str(self.walk_length) + " --num-walks " + str(
            self.number_walks) + " --window-size " + str(self.window_size) + " --p " + str(self.p) + " --q " + str(
            self.q) + " --iter " + str(self.iter) + " --workers " + str(self.workers)
        if self.weighted:
            command = command + " --weighted"
        if self.directed:
            command = command + " --directed"

        subprocess.call(command, shell=True)
