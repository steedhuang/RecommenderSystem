import subprocess

from embedding import SkipGramModel


class DeepwalkModel(SkipGramModel):

    def __init__(self, name, dimension, window_size, iter, number_walks, walk_length, undirected, input_filename,
                 output_embedding_filename, workers):
        super(DeepwalkModel, self).__init__(name, dimension, window_size, iter, output_embedding_filename, workers)
        self.set_walk_parameters(number_walks, walk_length, undirected)
        self.set_input(input_filename)

    def set_walk_parameters(self, number_walks, walk_length, undirected):
        self.number_walks = number_walks
        self.walk_length = walk_length
        self.undirected = undirected

    def set_input(self, input_filename):
        self.input = input_filename

    def embedding(self):
        subprocess.call(
            "deepwalk --input " + self.input + " --output " + self.output_embedding_filename + " --number-walks " + str(
                self.number_walks) + " --representation-size " + str(self.dimension) + " --walk-length " + str(
                self.walk_length) + " --window-size " + str(self.window_size) + " --undirected " + str(self.undirected),
            shell=True)
