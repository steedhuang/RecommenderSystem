from abc import ABCMeta, abstractmethod


class SkipGramModel(object):
    __metaclass__ = ABCMeta

    def __init__(self, name, dimension, window_size, iter, output_embedding_filename, workers):
        self.name = name
        self.set_word2vec_parameters(dimension, window_size, iter, workers)
        self.set_output(output_embedding_filename)

    def set_word2vec_parameters(self, dimension, window_size, iter, workers):
        self.dimension = dimension
        self.window_size = window_size
        self.iter = iter
        self.min_count = 0
        self.sg = 1
        self.workers = workers

    @abstractmethod
    def set_walk_parameters(self):
        pass

    @abstractmethod
    def set_input(self):
        pass

    def set_output(self, output_embedding_filename):
        self.output_embedding_filename = output_embedding_filename

    @abstractmethod
    def embedding(self):
        pass
