from gensim.models import Word2Vec

from embedding import SkipGramModel


class Word2vecModel(SkipGramModel):

    def __init__(self, name, dimension, window_size, iter, input_sequence, output_embedding_filename, workers):
        super(Word2vecModel, self).__init__(name, dimension, window_size, iter, output_embedding_filename, workers)
        self.set_input(input_sequence)

    def set_input(self, input_sequence):
        self.input = input_sequence

    def set_walk_parameters(self):
        pass

    def embedding(self):
        sequences = [map(str, walk) for walk in self.input]
        model = Word2Vec(sequences, size=self.dimension, window=self.window_size, min_count=self.min_count, sg=self.sg,
                         workers=self.workers, iter=self.iter)
        model.wv.save_word2vec_format(self.output_embedding_filename)
