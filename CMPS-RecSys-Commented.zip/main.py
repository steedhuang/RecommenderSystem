from config import ITEM_GRAPH_DATAS_PATH
from workflow import Workflow
from sampling.learning_network_sampling import LearningNetworksSampling
from embedding.node2vec import Node2vecModel
from recommender.cpms import CPMS

if __name__ == "__main__":
    db_name = "ml100k"
    sample_model = LearningNetworksSampling(db_name, 1, ITEM_GRAPH_DATAS_PATH + db_name + '-train-timeline-node2vec.edgelist')
    sample_model.sample()
    embedding_model = Node2vecModel("node2vec", 256, 10, 5, 50, 80, 1, 0.25, True, True,
                                   ITEM_GRAPH_DATAS_PATH + db_name + "-train-timeline-node2vec.edgelist",
                                   db_name + "-i2i.node2vecembeddings", 8)
    recommender_model = CPMS(db_name, db_name + "-i2i.node2vecembeddings", test_dict=sample_model.test_dataset)
    workflow_instance = Workflow(sample_model, embedding_model, recommender_model)
    workflow_instance.run()
