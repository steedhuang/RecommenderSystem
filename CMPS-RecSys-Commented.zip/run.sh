#!/usr/bin/env bash
# End of maintenance
# source venv/bin/active
# Build database
# python util.py

# Define datatype (Stay consistent with config.py)
db_name='mooc'

# Generate figures
cd scripts/item_graph/
python generate_edgelist.py
cd ../../

echo "finish generate i2i edgelist"

cd scripts/user-item-graph/
python generate_edgelist.py
cd ../..

echo "finish generate u2i edgelist"

# embedding
echo "deepwalk i2i"
deepwalk --input datas/item-graph/${db_name}-train-timeline-deepwalk.edgelist --output scripts/${db_name}-i2i.deepwalkembeddings --number-walks 50 --representation-size 256 --walk-length 80 --window-size 10 --undirected False
echo "deepwalk u2i"
deepwalk --input datas/user-item-graph-timeline/${db_name}-train-timeline.edgelist  --output scripts/${db_name}-u2i.deepwalkembeddings --number-walks 50 --representation-size 256 --walk-length 80 --window-size 10
echo "node2vec i2i"
python model/node2vec/src/main.py --input datas/item-graph/${db_name}-train-timeline-node2vec.edgelist --output scripts/${db_name}-i2i.node2vecembeddings --dimensions 256 --walk-length 80 --num-walks 50 --window-size 10 --p 1 --q 0.25 --iter 5 --workers 70 --weighted --directed
echo "node2vec u2i"
python model/node2vec/src/main.py --input datas/user-item-graph-timeline/${db_name}-train-timeline.edgelist --output scripts/${db_name}-u2i.node2vecembeddings --dimensions 256 --walk-length 80 --num-walks 50 --window-size 10 --p 1 --q 0.25 --iter 5 --workers 70

# evaluate
cd scripts/
python evaluate_single_one.py
