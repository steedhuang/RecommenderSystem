import sys

sys.path.append("../../")

from hyperparameter.grid_time_dynamic_search import TimeDynamicRecommendation
from utils.tools import send_email
from config import ITEM_GRAPH_DATAS_PATH

if __name__ == '__main__':
    TimeDynamicRecommendation('ml100k', 'item').node2vec_multi_run(data_path=ITEM_GRAPH_DATAS_PATH, process_workers=70,
                                                                   weighted=True, directed=True)
    send_email(['youremail@yourserver.yourcom'], "finish item-graph embedding program",
               "TimeDynamicRecommendation('ml100k', 'item').node2vec_multi_run(data_path=ITEM_GRAPH_DATAS_PATH, process_workers=70, weighted=True, directed=True)")
