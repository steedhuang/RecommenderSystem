import sys

sys.path.append("../../")

from hyperparameter.grid_time_dynamic_search import TimeDynamicRecommendation
from utils.tools import send_email
from config import ITEM_GRAPH_DATAS_PATH

if __name__ == '__main__':
    TimeDynamicRecommendation('ml100k', 'item').node2vec_grid_evaluate(data_path=ITEM_GRAPH_DATAS_PATH,
                                                                       result_path='evaluate_100k_item_graph_result_with_falloff.csv',
                                                                       process_workers=1)

    send_email(['youremail@yourserver.yourcom'], "finish item-graph evaluate program with_falloff",
               """
    TimeDynamicRecommendation('ml100k', 'item').node2vec_grid_evaluate(data_path=ITEM_GRAPH_DATAS_PATH,
                                                                       result_path='evaluate_100k_item_graph_result_with_falloff.csv',
                                                                       process_workers=1)
    """)
