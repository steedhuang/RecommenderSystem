import sys

sys.path.append("../../")

from hyperparameter.grid_time_dynamic_search import TimeDynamicRecommendation
from utils.tools import send_email
from config import USER_ITEM_GRAPH_DATAS_PATH

if __name__ == '__main__':
    TimeDynamicRecommendation('ml100k', 'user-item').node2vec_multi_run(data_path=USER_ITEM_GRAPH_DATAS_PATH,
                                                                        process_workers=70)
    send_email(['727342027@qq.com'], "finish user-item-timeline-graph embedding program",
               """
               TimeDynamicRecommendation('ml100k', 'user-item').node2vec_multi_run(data_path=USER_ITEM_GRAPH_DATAS_PATH,
                                                                        process_workers=70)""")
