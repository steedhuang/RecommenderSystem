import sys

sys.path.append("../../")

from hyperparameter.grid_time_dynamic_search import TimeDynamicRecommendation
from utils.tools import send_email
from config import USER_ITEM_GRAPH_DATAS_PATH

if __name__ == '__main__':
    TimeDynamicRecommendation('ml100k', 'user-item').node2vec_grid_evaluate(
        data_path=USER_ITEM_GRAPH_DATAS_PATH, result_path='evaluate_100k_user_item_graph_result.csv',
        process_workers=1)
    send_email(['727342027@qq.com'], "finish user-item-graph evaluate program",
               """
        TimeDynamicRecommendation('ml100k', 'user-item').node2vec_grid_evaluate(
        data_path=USER_ITEM_GRAPH_DATAS_PATH, result_path='evaluate_100k_user_item_graph_result.csv',
        process_workers=1)
    """)
