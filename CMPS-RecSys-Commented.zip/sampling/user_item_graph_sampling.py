import collections
import random

from config import THRESHOLD, USER_ITEM_GRAPH_DATAS_PATH
from sampling import Sampling
from utils.db import DB


class UserItemGraphSampling(Sampling):

    def __init__(self, db_name, addidamount, train_dataset_filename, test_dataset_filename):
        super(UserItemGraphSampling, self).__init__(db_name, train_dataset_filename, test_dataset_filename)
        self.addidamount = addidamount

    def load_dataset(self):
        if self.data is None:
            self.data = DB(self.db_name).load_dataset_with_ordered_timeleine()

    def divide_train_test_dataset(self):
        if self.train_dataset is None and self.test_dataset is None:
            user_ids = self.data.user_id.unique()
            train_user_item_pair, test_user_item_pair = {}, {}
            for user in user_ids:
                user_history = self.data.loc[(self.data.user_id == user) & (self.data.rating > THRESHOLD)]
                groups = user_history.groupby('time').groups
                items_with_timeline_for_user = []

                for key, value in collections.OrderedDict(sorted(groups.items())).items():
                    items_with_timeline_for_user.append(list(user_history.loc[value].item_id))

                if len(items_with_timeline_for_user) > 1:
                    tmp = []
                    for items in items_with_timeline_for_user[0:-1]:
                        tmp += items
                    train_user_item_pair[user] = tmp
                    test_user_item_pair[user] = items_with_timeline_for_user[-1]
            self.train_dataset = train_user_item_pair
            self.test_dataset = test_user_item_pair

    def save_train_dataset_to_file(self):
        # f = open(USER_ITEM_GRAPH_DATAS_PATH + self.db_name + '-train-timeline.edgelist', 'w')
        f = open(self.train_dataset_filename, 'w')
        train_pair = []
        for user, items in self.train_dataset.items():
            for item in items:
                train_pair.append((user, item + self.addidamount))
        random.shuffle(train_pair)
        for user, item in train_pair:
            f.write(str(user) + '    ' + str(item) + '\n')
        f.close()

    def save_test_dataset_to_file(self):
        # f = open(USER_ITEM_GRAPH_DATAS_PATH + self.db_name + '-test-timeline.edgelist', 'w')
        f = open(self.test_dataset_filename, 'w')
        for user, items in self.test_dataset.items():
            for item in items:
                f.write(str(user) + '    ' + str(item + self.addidamount) + '\n')
        f.close()
