from sampling import Sampling
from utils.db import DB


class UserBehaviourItemSequencesSampling(Sampling):

    def load_dataset(self):
        if self.data is None:
            db = DB(self.db_name)
            user_ids = db.get_user_ids()
            self.data = [db.get_history_items_with_user_id(user_id) for user_id in user_ids]

    def divide_train_test_dataset(self):
        if self.train_dataset is None:
            self.train_dataset = [[j[0] for j in i if j[2] != i[-1][2]] for i in self.data]
            # self.test_dataset # TODO

    def save_train_dataset_to_file(self):
        pass

    def save_test_dataset_to_file(self):
        pass

