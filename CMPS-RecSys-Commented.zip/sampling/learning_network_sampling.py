import collections

from sampling import Sampling
from utils.db import DB
from utils.tools import get_weighed_graph_train_counter_test_dict_by_timeline


class LearningNetworksSampling(Sampling):
    def __init__(self, db_name, method, train_dataset_filename, test_dataset_filename=None):
        super(LearningNetworksSampling, self).__init__(db_name, train_dataset_filename, test_dataset_filename)
        self.method = method

    def load_dataset(self):
        # data: DataFrame sorted by ['user_id', 'time']
        if self.data is None:
            self.data = DB(self.db_name).load_dataset_with_ordered_timeleine()

    def divide_train_test_dataset(self):
        """
        train_counter(weighed_graph), test_user_item_dict(test set with last timestmap user: [items, ])
        """
        if self.train_dataset is None and self.test_dataset is None:
            self.train_dataset, self.test_dataset = get_weighed_graph_train_counter_test_dict_by_timeline(self.data)

    def save_train_dataset_to_file(self):
        # for deepwalk
        if self.method == 0:
            f = open(self.train_dataset_filename, 'w')
            for key, value in self.train_dataset.items():
                f.write(str(key[0]) + ' ' + str(key[1]) + '\n')

        # for node2vec
        if self.method == 1:
            f = open(self.train_dataset_filename, 'w')
            for key, value in self.train_dataset.items():
                f.write(str(key[0]) + ' ' + str(key[1]) + ' ' + str(value) + '\n')

    def save_test_dataset_to_file(self):  # TODO
        pass

    @staticmethod
    def remove_graph_cycle(graph_counter):
        edge_pairs_list = graph_counter.keys()
        edge_pairs_list_sort = [tuple(sorted(list(i))) for i in edge_pairs_list]
        edge_pair_counter = collections.Counter(edge_pairs_list_sort)
        edge_pairs_set_diff = [key for key, value in edge_pair_counter.items() if value == 2]
        for pair in edge_pairs_set_diff:
            a, b = pair
            if graph_counter[(a, b)] > graph_counter[(b, a)]:
                graph_counter[(a, b)] = graph_counter[(a, b)] - graph_counter[(b, a)]
                del graph_counter[(b, a)]
            elif graph_counter[(a, b)] == graph_counter[(b, a)]:
                del graph_counter[(b, a)]
                del graph_counter[(a, b)]
            elif graph_counter[(a, b)] < graph_counter[(b, a)]:
                graph_counter[(b, a)] = graph_counter[(b, a)] - graph_counter[(a, b)]
                del graph_counter[(a, b)]
