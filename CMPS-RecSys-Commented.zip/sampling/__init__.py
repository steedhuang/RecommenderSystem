from abc import ABCMeta, abstractmethod


class Sampling(object):
    __metaclass__ = ABCMeta

    def __init__(self, db_name, train_dataset_filename=None, test_dataset_filename=None):
        self.db_name = db_name
        self.data = None
        self.train_dataset = None
        self.test_dataset = None
        self.train_dataset_filename = train_dataset_filename
        self.test_dataset_filename = test_dataset_filename

    @abstractmethod
    def load_dataset(self):
        # Need Cache
        pass

    @abstractmethod
    def divide_train_test_dataset(self):
        # Need Cache
        pass

    @abstractmethod
    def save_train_dataset_to_file(self):
        pass

    @abstractmethod
    def save_test_dataset_to_file(self):
        pass

    def sample(self):
        self.load_dataset()
        self.divide_train_test_dataset()

    def save_train_test_dataset_to_file(self):
        self.save_train_dataset_to_file()
        self.save_test_dataset_to_file()