# -*- coding: utf-8 -*-
THRESHOLD = 3.5
# ADDIDAMOUNT = 1387928050   # Must be greater than largest usr id for mooc
ADDIDAMOUNT = 1000   # Must be greater than largest usr id for ml100k
K_MOST_SIMILAR = 5
FALLOFF = 0.9
TOP_K = 5
NEGATIVE_SIZE = 50
# NEGATIVE_SIZE = 0   # All untouched items goes into candidate

# User specific modifications
PROJECT_ROOT_PATH = 'C:/Workspace/Unified-SER-Recsys-Framework/'
VIRTUALENV_PYTHON_PATH = 'C:/Workspace/Unified-SER-Recsys-Framework/venv/Scripts/python'

DB_PATH = PROJECT_ROOT_PATH + 'origin_data.db'
ITEM_GRAPH_DATAS_PATH = PROJECT_ROOT_PATH + 'datas/item-graph/'
USER_ITEM_GRAPH_DATAS_PATH = PROJECT_ROOT_PATH + 'datas/user-item-graph-timeline/'

# DB_NAME = "mooc"
DB_NAME = "ml100k"
# DB_NAME = "ml1m"
# DB_NAME = "goodbooks"

# LOGGER_LEVEL = "DEBUG"
LOGGER_LEVEL = "INFO"
