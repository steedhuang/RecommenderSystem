# -*- coding: utf-8 -*-
import pandas as pd
import matplotlib.pyplot as plt


class Analysis(object):
    """
    Parameter sensitivity analysis
    """

    def __init__(self, filename,
                 columns=None):
        if columns is None:
            columns = ['dimensions', 'walks_lengths', 'window_sizes', 'num_walks', 'p', 'q', 'iter_times',
                       'precision', 'recall']
        self.filename = filename
        self.df = pd.read_csv(filename, names=columns)  # , delim_whitespace=True)

    def paint(self, xlabel):
        """
        usage: >>> paint("dimension.csv", 'dimensions')
        :param xlabel:
        :return:
        """

        t = self.df.groupby([xlabel])[['precision', 'recall']].sum()

        x = t.index
        y1 = t.precision
        y2 = t.recall

        fig, ax = plt.subplots()
        plt.xlabel(xlabel)
        plt.ylabel('precision, recall')

        line1, = ax.plot(x, y1, label='precision')

        line2, = ax.plot(x, y2, label='recall')

        ax.legend()
        plt.show()