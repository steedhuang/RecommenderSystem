# -*- coding: utf-8 -*-
import collections
import itertools
import logging
import platform
import random
import smtplib
from email.mime.text import MIMEText
from itertools import product

from config import THRESHOLD, NEGATIVE_SIZE, LOGGER_LEVEL
from utils.db import DB

LOG_FORMAT = "%(asctime)s - %(levelname)s - %(message)s"
DATE_FORMAT = "%m/%d/%Y %H:%M:%S %p"
logging.basicConfig(format=LOG_FORMAT, datefmt=DATE_FORMAT, level=LOGGER_LEVEL)
logger = logging.getLogger("evaluate_single_one logger")


def load_hyparameters(*args):
    """
    for deepwalk:
    :param args: (dimensions, walks_lengths, window_sizes, num_walks)
    for node2vec:
    :param args: (dimensions, walks_lengths, window_sizes, num_walks, p, q, iter_times)
    :return:
    """
    hyparameters_table = product(*args)
    return hyparameters_table


def send_email(receivers, subject, content):
    mail_host = "smtp.163.com"
    mail_user = "zhangdb1996@163.com"
    mail_pass = "wy1640-02"
    sender = "zhangdb1996@163.com"

    machine_name = platform.node()

    message = MIMEText(machine_name + '\n' + content, 'plain', 'utf-8')
    message['Subject'] = subject
    message['From'] = sender
    message['To'] = ';'.join(receivers)

    smtp_obj = smtplib.SMTP()
    smtp_obj.connect(mail_host, 25)
    smtp_obj.login(mail_user, mail_pass)
    smtp_obj.sendmail(
        sender, receivers, message.as_string())
    smtp_obj.quit()


def get_user_history_by_user_id_from_origin_data_df(user_id, df, positive=False):
    if positive:  # only need rating > THRESHOLD result
        user_history = df.loc[(df.user_id == user_id) & (df.rating > THRESHOLD)]
    else:
        user_history = df.loc[(df.user_id == user_id)]
    return user_history


def get_weighed_graph_train_counter_test_dict_by_timeline(df):
    """
    :param DataFrame: origin dataset 'user_id', 'item_id', 'rating', 'time'
    :return: train_counter(weighed_graph), test_user_item_dict(test set with last timestmap user: [items, ])
    """
    user_ids = df.user_id.unique()
    item_relationships = []
    test_user_item_dict = {}
    for user in user_ids:
        user_history = get_user_history_by_user_id_from_origin_data_df(user, df,
                                                                       positive=True)  # only need rating > THRESHOLD result
        groups = user_history.groupby('time').groups
        items_with_timeline_for_user = []

        for key, value in collections.OrderedDict(sorted(groups.items())).items():
            items_with_timeline_for_user.append(list(user_history.loc[value].item_id))

        if len(items_with_timeline_for_user) > 1:
            for i in range(len(items_with_timeline_for_user) - 2):
                item_relationships += list(
                    itertools.product(items_with_timeline_for_user[i], items_with_timeline_for_user[i + 1]))
            test_user_item_dict[user] = items_with_timeline_for_user[-1]
    train_counter = collections.Counter(item_relationships)

    return train_counter, test_user_item_dict


def generate_candidate_items_by_k_negative_samples_for_user(db_name, user_id, test_positive_items, k):
    """
    :param db_name: ml100k or ml1m and so on
    :param user_id:
    :param test_positive_items:  positive items in test set
    :param k:
    :return: candidate_items
    """
    false_items = DB(db_name).get_items_not_in_user_id_history(user_id)
    if k > 0:
        positive_item_amount = k * len(test_positive_items)
        false_items = random.sample(false_items, positive_item_amount)
    candidate_items = test_positive_items + false_items
    return candidate_items


def get_clean_test_dict_and_candidate_items(db_name, test_dict, item_ids):
    candidate_items = {}
    logger.info("k: " + str(NEGATIVE_SIZE))
    for user in test_dict.keys():
        test_dict[user] = list(set(test_dict[user]).intersection(set(item_ids)))
        if test_dict[user]:
            candidate_item_user_t = generate_candidate_items_by_k_negative_samples_for_user(db_name, user_id=user,
                                                                                            test_positive_items=
                                                                                            test_dict[
                                                                                                user],
                                                                                            k=NEGATIVE_SIZE)
            candidate_items[user] = list(set(candidate_item_user_t).intersection(set(item_ids)))
        else:
            del test_dict[user]
    return test_dict, candidate_items
