# -*- coding: utf-8 -*-

import collections
import random
import sqlite3

from sklearn.model_selection import KFold

from config import THRESHOLD, DB_PATH, ADDIDAMOUNT


# TO be removed in the future! FIXME
class Edgelist(object):

    def __init__(self, db_name, k_fold_n=5, addidamount=ADDIDAMOUNT):
        self.db_name = db_name
        self.k_fold_n = k_fold_n
        self.addidamount = addidamount

    def generate_k_fold_edgelist_from_origin_data(self, write_path=''):
        conn = sqlite3.connect(DB_PATH)
        c = conn.cursor()
        c.execute('SELECT user_id, item_id FROM {} where rating>=?'.format(self.db_name), (THRESHOLD,))
        clean_data = [[i[0], i[1]] for i in c.fetchall()]
        conn.close()

        for i in clean_data:
            i[1] = str(int(i[1]) + self.addidamount)

        random.shuffle(clean_data)

        f = open(write_path + self.db_name + '.edgelist', 'w')
        for i in clean_data:
            f.write(str(i[0]) + '    ' + str(i[1]) + '\n')
        f.close()

        kf = KFold(n_splits=self.k_fold_n)
        kf.get_n_splits(clean_data)
        index = 0
        for train_index, test_index in kf.split(clean_data):
            train, test = map(clean_data.__getitem__, train_index), map(clean_data.__getitem__, test_index)
            index += 1
            f = open(write_path + self.db_name + '-train-' + str(index) + '.edgelist', 'w')
            for i in train:
                f.write(str(i[0]) + '    ' + str(i[1]) + '\n')
            f.close()

            f = open(write_path + self.db_name + '-test-' + str(index) + '.edgelist', 'w')
            for i in test:
                f.write(str(i[0]) + '    ' + str(i[1]) + '\n')
            f.close()

    def load_pair_dict_from_edgelist(self, edgelist_file):
        pair_dict = collections.defaultdict(list)
        with open(edgelist_file) as f:
            origin_data = f.readlines()
            raw_list = [i.split() for i in origin_data]
            cleaned_list = [(int(i[0]), int(i[1]) - self.addidamount) for i in raw_list]
            for user_id, item_id in cleaned_list:
                pair_dict[user_id].append(item_id)
        return pair_dict
