# -*- coding: utf-8 -*-

import sqlite3

import pandas as pd

from config import DB_PATH, PROJECT_ROOT_PATH


class DB(object):

    def __init__(self, db_name):
        self.db_name = db_name

    def create_db(self):
        if self.db_name == 'ml100k':
            self.create_ml_100k_db()
        elif self.db_name == 'ml1m':
            self.create_ml_1m_db()
        elif self.db_name == 'goodbooks':
            self.create_goodbooks_db()
        elif self.db_name == 'mooc':
            self.create_mooc_db()

    @staticmethod
    def create_ml_100k_db():
        conn = sqlite3.connect(DB_PATH)
        c = conn.cursor()
        c.execute(
            "CREATE TABLE ml100k(user_id INTEGER, item_id INTEGER, rating INTEGER, time INTEGER)"
        )
        with open(PROJECT_ROOT_PATH + "ml-100k/u.data") as f:
            while True:
                temp = f.readline().replace('\n', '').split()
                if len(temp) == 4:
                    c.execute("insert into ml100k values (?, ?, ?, ?)",
                              temp)
                elif len(temp) <= 1:
                    break
        conn.commit()
        conn.close()

    @staticmethod
    def create_ml_1m_db():
        conn = sqlite3.connect(DB_PATH)
        c = conn.cursor()
        c.execute(
            "CREATE TABLE ml1m(user_id INTEGER, item_id INTEGER, rating INTEGER, time INTEGER)"
        )
        with open(PROJECT_ROOT_PATH + "ml-1m/ratings.dat") as f:
            while True:
                temp = f.readline().replace('\n', '').split('::')
                if len(temp) == 4:
                    c.execute("insert into ml1m values (?, ?, ?, ?)",
                              temp)
                elif len(temp) <= 1:
                    break
        conn.commit()
        conn.close()

    @staticmethod
    def create_goodbooks_db():
        conn = sqlite3.connect(DB_PATH)
        c = conn.cursor()
        c.execute(
            "CREATE TABLE goodbooks(user_id INTEGER, item_id INTEGER, rating INTEGER, time INTEGER)"
        )
        with open(PROJECT_ROOT_PATH + "goodbooks/ratings.csv") as f:
            f.readline()
            index = 0
            while True:
                temp = f.readline().replace('\n', '').split(',')
                index += 1
                if len(temp) == 3:
                    temp.append(int(index / 10))
                    c.execute("insert into goodbooks values (?, ?, ?, ?)",
                              temp)
                elif len(temp) <= 1:
                    break
        conn.commit()
        conn.close()

    @staticmethod
    def create_mooc_db():
        conn = sqlite3.connect(DB_PATH)
        c = conn.cursor()
        c.execute('''CREATE TABLE mooc
                    (user_id INTEGER, item_id INTEGER, rating REAL, time INTEGER)''')
        with open(PROJECT_ROOT_PATH + "mooc/comment_info.csv") as f:
            for i in f.readlines()[1:-1]:
                temp = i.strip().split(",")
                c.execute("INSERT INTO mooc VALUES (?,?,?,?)", [temp[2], temp[4], temp[3], temp[1]])
        conn.commit()
        conn.close()

    def get_history_items_with_user_id(self, user_id):
        conn = sqlite3.connect(DB_PATH)
        c = conn.cursor()
        c.execute('SELECT item_id,rating,time FROM {} WHERE user_id=? ORDER BY time'.format(self.db_name), (int(user_id),))
        result = c.fetchall()
        conn.close()
        return result

    def get_items_not_in_user_id_history(self, user_id):
        conn = sqlite3.connect(DB_PATH)
        c = conn.cursor()
        c.execute('SELECT item_id FROM {} WHERE user_id=?'.format(self.db_name), (int(user_id),))   # convert python numpy.int64 to int

        all_item_ids = set(self.get_item_ids())
        history_item_ids = set([i[0] for i in c.fetchall()])

        conn.close()
        return list(all_item_ids.difference(history_item_ids))

    def get_user_ids(self):
        conn = sqlite3.connect(DB_PATH)
        c = conn.cursor()

        c.execute('SELECT DISTINCT user_id FROM {}'.format(self.db_name))
        result = [i[0] for i in c.fetchall()]
        conn.close()
        return result

    def get_item_ids(self):
        conn = sqlite3.connect(DB_PATH)
        c = conn.cursor()

        c.execute('SELECT DISTINCT item_id FROM {}'.format(self.db_name))
        result = [i[0] for i in c.fetchall()]
        conn.close()
        return result

    def load_dataset_with_ordered_timeleine(self):
        """
        :return: dataframe sorted by ['user_id', 'time']
        """
        conn = sqlite3.connect(DB_PATH)
        df = pd.read_sql_query("select * from {}".format(self.db_name), conn).sort_values(['user_id', 'time'])
        conn.close()
        return df


if __name__ == '__main__':
    DB('ml100k').create_db()
    # DB('mooc').create_db()
    # DB('ml1m').create_db()
# DB('goodbooks').create_db()
