import logging

from config import LOGGER_LEVEL

LOG_FORMAT = "%(asctime)s - %(levelname)s - %(message)s"
DATE_FORMAT = "%m/%d/%Y %H:%M:%S %p"
logging.basicConfig(format=LOG_FORMAT, datefmt=DATE_FORMAT, level=LOGGER_LEVEL)
logger = logging.getLogger("evaluate_single_one logger")


def evaluate(recommendation_result, test_pair):
    """
    :param recommendation_result: dict user:item_list
    :param test_pair:   dict user:item_list (all positive items)
    :return:
    """
    precisions = {}
    precisions_2 = {}
    recalls = {}
    recalls_2 = {}
    for user_id, items in recommendation_result.iteritems():
        test_items = test_pair[user_id]

        # logger debug
        logger.debug("user: " + str(user_id) + " test_items: " + ",".join(
            [str(i) for i in test_items]) + " recommendations: " + ",".join([str(i) for i in items]))

        hit_items = [i for i in items if i in test_items]
        precisions[user_id] = len(hit_items)
        precisions_2[user_id] = len(items)
        if len(test_items) > 0:
            recalls[user_id] = len(hit_items)
            recalls_2[user_id] = len(test_items)
    mean_precision = sum(precisions.values()) / float(sum(precisions_2.values()))
    mean_recall = sum(recalls.values()) / float(sum(recalls_2.values()))

    logger.info("precision: " + str(mean_precision) + " recall: " + str(mean_recall))
    return mean_precision, mean_recall