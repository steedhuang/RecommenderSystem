import pandas as pd
from sklearn.metrics.pairwise import cosine_similarity


# TODO to be refactor

def get_similarity_matrix_csv_from_user_item_embedding(embedding_file, addidamount, to_csv=False):
    df = pd.read_csv(embedding_file, skiprows=1, delim_whitespace=True, header=None)
    user_df = df.loc[df[0] < addidamount]
    item_df = df.loc[df[0] >= addidamount]
    user_ids = user_df[0].reset_index(drop=True)
    item_ids = item_df[0].apply(lambda x: int(x) - addidamount).reset_index(drop=True)
    user_matrix = user_df.drop([0], axis=1).as_matrix()
    item_matrix = item_df.drop([0], axis=1).as_matrix()
    similarity_matrix = cosine_similarity(user_matrix, item_matrix)
    similarity_df = pd.DataFrame(similarity_matrix)
    similarity_df.insert(0, 'id', user_ids)
    items_ids_columns = list(item_ids)
    items_ids_columns.insert(0, 'ids')
    similarity_df.columns = items_ids_columns
    if to_csv:
        similarity_df.to_csv('similarity_result.csv', index=False)
    return similarity_df


def get_similarity_matrix_csv_from_homogeneous_embedding(embedding_file, to_csv=False):
    df = pd.read_csv(embedding_file, skiprows=1, delim_whitespace=True, header=None)

    item_ids = df[0]
    item_matrix = df.drop([0], axis=1).as_matrix()
    similarity_matrix = cosine_similarity(item_matrix)
    similarity_df = pd.DataFrame(similarity_matrix)

    similarity_df.insert(0, 'id', item_ids)
    items_ids_columns = list(item_ids)
    items_ids_columns.insert(0, 'ids')
    similarity_df.columns = items_ids_columns
    if to_csv:
        similarity_df.to_csv('similarity_result.csv', index=False)
    return similarity_df
