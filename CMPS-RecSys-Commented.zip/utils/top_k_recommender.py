import logging
import operator
from collections import defaultdict

from config import THRESHOLD, K_MOST_SIMILAR, FALLOFF, LOGGER_LEVEL, TOP_K
from utils.db import DB

LOG_FORMAT = "%(asctime)s - %(levelname)s - %(message)s"
DATE_FORMAT = "%m/%d/%Y %H:%M:%S %p"
logging.basicConfig(format=LOG_FORMAT, datefmt=DATE_FORMAT, level=LOGGER_LEVEL)
logger = logging.getLogger("evaluate_single_one logger")


def top_k_rec_for_user_item_similarity_matrix(similarity_df, train_pair, k, given_candidate_items=None):
    """
    candidate items as items not appear in user i's train-set history.
    :param similarity_df: user-item similarity matrix
    :param train_pair: train data set
    :param k: top-k size
    :return:
    """
    recommendation_result = {}
    for index, row in similarity_df.iterrows():
        raw_similarity = [(index, value) for index, value in row.iteritems()]
        user_id = raw_similarity[0][1]
        raw_similarity_remove_user_id = [(index, value) for index, value in row.iteritems()][1:]
        sorted_similarity = sorted(raw_similarity_remove_user_id, key=lambda l: l[1], reverse=True)  # list(tuple())

        if given_candidate_items:
            if user_id in given_candidate_items.keys():
                candidate_items = given_candidate_items[int(user_id)]  # list
                sorted_candidate_items = [i[0] for i in sorted_similarity if i[0] in candidate_items]
                recommendation_result[int(user_id)] = [i for i in sorted_candidate_items][0:k]

                # logger debug
                candidate_items_str = ",".join([str(c) for c in candidate_items])
                recommendation_result_str = ",".join([str(r) for r in recommendation_result[int(user_id)]])
                logger.debug("user: " + str(user_id) + " candidate_item for user: "
                             + candidate_items_str + " recommendation for user: " + recommendation_result_str)
        else:
            train_history = train_pair[user_id]
            candidate_items = [i[0] for i in sorted_similarity]
            recommendation_result[user_id] = [i for i in candidate_items if i not in train_history][0:k]
    return recommendation_result


# TODO to be refactor
def top_k_rec_by_item_similarity_matrix_for_user(user_id, similarity_df, candidate_items, k, table_name):
    """
    2. for each positive item in the test set, we randomly sample 50 negative samples that have no interaction records with the target user. Then, we rank the list consisting of the positive item and 50 negative items
    3. the leave-one-out evaluation
    :param table_name: dataset
    :param user_id: user_id
    :param similarity_df: user-item or item-item similarity matrix
    :param candidate_items: candidate items for top-k recommendation
    :param k: top-k size
    :return: recommendations (k items for each user)
    """
    rank = defaultdict(lambda: 0)
    user_history = DB(table_name).get_history_items_with_user_id(user_id)
    user_like_history = [i for i in user_history if i[1] > THRESHOLD]
    item_ids = similarity_df.columns[1:]
    candidate_items = list(set(candidate_items).intersection(set(item_ids)))
    falloff = 1
    for item_id, rating, _ in user_like_history[::-1]:
        if item_id in item_ids:
            item_id_similarity = similarity_df.loc[similarity_df['ids'] == item_id][candidate_items]
            item_id_similarity_list = [(name, value.values[0]) for name, value in item_id_similarity.iteritems()]
            sorted_item_id_similarity_list = sorted(item_id_similarity_list, key=lambda l: l[1], reverse=False)[
                                             0:K_MOST_SIMILAR]
            for iid, similarity_ii in sorted_item_id_similarity_list:
                rank[iid] += similarity_ii * rating * falloff
            falloff = falloff * FALLOFF
    rank_sort_result = sorted(rank.items(), key=operator.itemgetter(1), reverse=False)[0:k]
    recommendation_result = [i[0] for i in rank_sort_result]
    return recommendation_result  # result can be sent to def evaluate(recommendation_result, test_pair) to evaluate

def get_item_graph_recommendation_for_user(db_name, user_id, similarity_df, candidate_items):
    """
    for item_similarity_matrix
    """
    recommendation_result = top_k_rec_by_item_similarity_matrix_for_user(user_id=user_id,
                                                                         similarity_df=similarity_df,
                                                                         candidate_items=candidate_items,
                                                                         k=TOP_K,
                                                                         table_name=db_name)
    candidate_items_str = ",".join([str(c) for c in candidate_items])
    recommendation_result_str = ",".join([str(r) for r in recommendation_result])
    logger.debug("user: " + str(user_id) + " candidate_item for user: "
                 + candidate_items_str + " recommendation for user: " + recommendation_result_str)
    return recommendation_result


def get_item_graph_recommendation_for_user_helper(args):
    return get_item_graph_recommendation_for_user(*args)