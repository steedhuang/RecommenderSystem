# -*- coding: utf-8 -*-
import sys

sys.path.append("../../")
from utils.db import DB


def generate_sequences(db_name):
    db = DB(db_name)
    user_ids = db.get_user_ids()
    seq_with_rating = [db.get_history_items_with_user_id(user_id) for user_id in user_ids]
    seq = [[j[0] for j in i if j[2] != i[-1][2]] for i in seq_with_rating]
    return seq


if __name__ == '__main__':
    generate_sequences('ml100k')
