# -*- coding: utf-8 -*-
"""
usage:
python main.py --input-db ml100k --output word2vec_ml100k_result.embeddings --dimensions 256 --window-size 10 --iter 5 --workers 8
"""
import argparse

from gensim.models import Word2Vec

from sampling.user_bahaviour_item_sequences_sampling import UserBehaviourItemSequencesSampling


def parse_args():
    """
    Parses the node2vec arguments.
    """
    parser = argparse.ArgumentParser(description="Run word2vec.")

    parser.add_argument('--input-db', nargs='?', default='ml100k',
                        help='Input db name')

    parser.add_argument('--output', nargs='?', default='emb/karate.emb',
                        help='Embeddings path')

    parser.add_argument('--dimensions', type=int, default=128,
                        help='Number of dimensions. Default is 128.')

    parser.add_argument('--window-size', type=int, default=10,
                        help='Context size for optimization. Default is 10.')

    parser.add_argument('--iter', default=1, type=int,
                        help='Number of epochs in SGD')

    parser.add_argument('--workers', type=int, default=8,
                        help='Number of parallel workers. Default is 8.')

    return parser.parse_args()


def learn_embeddings(sequences):
    """
    Learn embeddings by optimizing the Skip-gram objective using SGD.
    """
    sequences = [map(str, walk) for walk in sequences]
    model = Word2Vec(sequences, size=args.dimensions, window=args.window_size, min_count=0, sg=1, workers=args.workers,
                     iter=args.iter)
    model.wv.save_word2vec_format(args.output)

    return


def main(args):
    """
    Pipeline for representational learning for all nodes in a graph.
    """
    # seq = word2vec.generate_sequences(args.input_db)
    sample_model = UserBehaviourItemSequencesSampling(args.input_db)
    sample_model.sample()
    learn_embeddings(sample_model.train_dataset)


if __name__ == "__main__":
    args = parse_args()
    main(args)
