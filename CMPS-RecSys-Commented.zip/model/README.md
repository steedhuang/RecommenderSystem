By `build_graph_by_timeline` with item similarity
ml-100k precision, recall is  (0.06830969267139525, 0.4385431442080378)

Compare with node2vec with user item similarity
ml-100k precision, recall is  (0.04276595744680877, 0.29838736913204994)

Situations encountered:
- item_id not in similarity_df when calculating the neighbors of the item_id (Simply skip these items)
- Candidate set is only presented in the test set, not in the similarity_df (Remove it from test set, since the user recommendation result has 0 hit probability if they are only presented in the test set)

