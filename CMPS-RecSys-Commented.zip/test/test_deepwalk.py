from config import ITEM_GRAPH_DATAS_PATH, USER_ITEM_GRAPH_DATAS_PATH
from embedding.deepwalk import DeepwalkModel

if __name__ == "__main__":
    db_name = "ml100k"
    deepwalk_model = DeepwalkModel("deepwalk", 256, 10, 5, 50, 80, False,
                                   ITEM_GRAPH_DATAS_PATH + db_name +"-train-timeline-deepwalk.edgelist",
                                   db_name + "-i2i.deepwalkembeddings", 8)
    deepwalk_model.embedding()

    deepwalk_model2 = DeepwalkModel("deepwalk", 256, 10, 5, 50, 80, True,
                                    USER_ITEM_GRAPH_DATAS_PATH + db_name + "-train-timeline.edgelist",
                                   db_name + "-u2i.deepwalkembeddings", 8)
    deepwalk_model2.embedding()