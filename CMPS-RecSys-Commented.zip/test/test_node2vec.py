from config import ITEM_GRAPH_DATAS_PATH, USER_ITEM_GRAPH_DATAS_PATH
from embedding.node2vec import Node2vecModel

if __name__ == "__main__":
    db_name = "ml100k"
    node2vec_model = Node2vecModel("node2vec", 256, 10, 5, 50, 80, 1, 0.25, True, True,
                                   ITEM_GRAPH_DATAS_PATH + db_name + "-train-timeline-node2vec.edgelist",
                                   db_name + "-i2i.node2vecembeddings", 8)
    node2vec_model.embedding()

    node2vec_model2 = Node2vecModel("node2vec", 256, 10, 5, 50, 80, 1, 0.25, False, False,
                                    USER_ITEM_GRAPH_DATAS_PATH + db_name + "-train-timeline.edgelist",
                                    db_name + "-u2i.node2vecembeddings", 8)
    node2vec_model2.embedding()