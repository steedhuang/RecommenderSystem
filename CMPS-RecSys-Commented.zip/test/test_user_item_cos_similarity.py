from recommender.user_item_cos_similarity import UserItemCosSimilarity
from utils.db import DB
from utils.evaluation import evaluate
from utils.tools import get_weighed_graph_train_counter_test_dict_by_timeline

if __name__ == "__main__":
    db_name = "ml100k"
    df = DB(db_name).load_dataset_with_ordered_timeleine()
    _, test_dict = get_weighed_graph_train_counter_test_dict_by_timeline(df)

    user_item_cos_similarity_model = UserItemCosSimilarity(db_name, db_name + "-u2i.deepwalkembeddings", test_dict, 1000)

    user_item_cos_similarity_model.recommender()

    evaluate_result = evaluate(user_item_cos_similarity_model.recommendation_results,
                               user_item_cos_similarity_model.test_dict)