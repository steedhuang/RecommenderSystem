from config import USER_ITEM_GRAPH_DATAS_PATH, ITEM_GRAPH_DATAS_PATH
from sampling.user_item_graph_sampling import UserItemGraphSampling
from sampling.learning_network_sampling import LearningNetworksSampling

if __name__ == '__main__':
    db_name = "ml100k"
    user_item_graph_sampling = UserItemGraphSampling(db_name, 1000,
                                                     USER_ITEM_GRAPH_DATAS_PATH + db_name + '-train-timeline.edgelist',
                                                     USER_ITEM_GRAPH_DATAS_PATH + db_name + '-test-timeline.edgelist')
    user_item_graph_sampling.sample()
    user_item_graph_sampling.save_train_test_dataset_to_file()

    learning_networks_sampling = LearningNetworksSampling(db_name, 0,
                                                          ITEM_GRAPH_DATAS_PATH + db_name + '-train-timeline-deepwalk.edgelist')
    learning_networks_sampling.sample()
    # for deepwalk
    learning_networks_sampling.save_train_test_dataset_to_file()
    # for node2vec
    learning_networks_sampling.method = 1
    learning_networks_sampling.train_dataset_filename = ITEM_GRAPH_DATAS_PATH + db_name + '-train-timeline-node2vec.edgelist'
    learning_networks_sampling.save_train_test_dataset_to_file()
