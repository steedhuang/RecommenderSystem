from embedding.word2vec import Word2vecModel
from sampling.user_bahaviour_item_sequences_sampling import UserBehaviourItemSequencesSampling

if __name__ == "__main__":
    sample_model = UserBehaviourItemSequencesSampling("ml100k")
    sample_model.sample()
    word2vec_model = Word2vecModel("word2vec", 256, 10, 5, sample_model.train_dataset,
                                   "word2vec_ml100k_result.embeddings", 8)
    word2vec_model.embedding()
