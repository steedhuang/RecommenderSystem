from recommender.item_based_cf import ItemBasedCF
from utils.db import DB
from utils.evaluation import evaluate
from utils.tools import get_weighed_graph_train_counter_test_dict_by_timeline

if __name__ == "__main__":
    db_name = "ml100k"
    df = DB(db_name).load_dataset_with_ordered_timeleine()

    _, test_dict = get_weighed_graph_train_counter_test_dict_by_timeline(df)

    item_based_cf_model = ItemBasedCF(db_name, db_name + "-i2i.deepwalkembeddings", test_dict)

    item_based_cf_model.recommender()

    print evaluate(item_based_cf_model.recommendation_results, item_based_cf_model.test_dict)