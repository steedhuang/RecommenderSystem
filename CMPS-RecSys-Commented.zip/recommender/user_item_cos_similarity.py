from utils.similarity import get_similarity_matrix_csv_from_user_item_embedding
from config import TOP_K
from utils.top_k_recommender import top_k_rec_for_user_item_similarity_matrix
from recommender import Recommender


class UserItemCosSimilarity(Recommender):

    def __init__(self, db_name, embedding_result_filename, test_dict, addidamount):
        super(UserItemCosSimilarity, self).__init__(db_name, embedding_result_filename, test_dict)
        self.addidamount = addidamount

    def generate_similarity_matrix(self):
        self.similarity_matrix = get_similarity_matrix_csv_from_user_item_embedding(self.embedding_result_filename,
                                                                                    self.addidamount)

    def get_recommendation_result(self):
        self.recommendation_results = top_k_rec_for_user_item_similarity_matrix(self.similarity_matrix, {}, TOP_K,
                                                                                self.candidate_items)
