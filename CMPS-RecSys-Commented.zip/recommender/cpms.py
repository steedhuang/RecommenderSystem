from multiprocessing import Pool

import pandas as pd
import numpy as np
from scipy.spatial.distance import pdist, squareform

from recommender import Recommender
from utils.top_k_recommender import get_item_graph_recommendation_for_user_helper


class CPMS(Recommender):
    def generate_similarity_matrix(self):
        df = pd.read_csv(self.embedding_result_filename, skiprows=1, delim_whitespace=True, header=None)
        item_ids = df[0]
        item_matrix = df.drop([0], axis=1).as_matrix()
        similarity_matrix = pdist(item_matrix,
                                  lambda u, v: np.sqrt(np.linalg.norm(u) * np.linalg.norm(v) - np.dot(u, v)))
        similarity_df = pd.DataFrame(squareform(similarity_matrix))
        similarity_df.insert(0, 'id', item_ids)
        items_ids_columns = list(item_ids)
        items_ids_columns.insert(0, 'ids')

        similarity_df.columns = items_ids_columns
        self.similarity_matrix = similarity_df


    def get_recommendation_result(self):
        recommendation_result = {}

        user_list = list(self.test_dict.keys())
        # logger.info("multiprocess get recommendation results")

        pool = Pool()
        parameters = ((self.db_name, user, self.similarity_matrix, self.candidate_items[user]) for user in user_list)

        pool_outputs = pool.map(get_item_graph_recommendation_for_user_helper, parameters)

        for counter, user in enumerate(user_list):
            recommendation_result[user] = pool_outputs[counter]

        pool.close()
        pool.join()

        self.recommendation_results = recommendation_result