from multiprocessing import Pool

from utils.similarity import get_similarity_matrix_csv_from_homogeneous_embedding
from utils.top_k_recommender import get_item_graph_recommendation_for_user_helper
from recommender import Recommender


class ItemBasedCF(Recommender):

    def generate_similarity_matrix(self):
        self.similarity_matrix = get_similarity_matrix_csv_from_homogeneous_embedding(self.embedding_result_filename)

    def get_recommendation_result(self):
        recommendation_result = {}

        user_list = list(self.test_dict.keys())
        # logger.info("multiprocess get recommendation results")

        pool = Pool()
        parameters = ((self.db_name, user, self.similarity_matrix, self.candidate_items[user]) for user in user_list)

        pool_outputs = pool.map(get_item_graph_recommendation_for_user_helper, parameters)

        for counter, user in enumerate(user_list):
            recommendation_result[user] = pool_outputs[counter]

        pool.close()
        pool.join()

        self.recommendation_results = recommendation_result
