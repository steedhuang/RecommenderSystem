from abc import ABCMeta, abstractmethod

from utils.tools import get_clean_test_dict_and_candidate_items


class Recommender(object):
    __metaclass__ = ABCMeta

    def __init__(self, db_name, embedding_result_filename, test_dict):
        self.db_name = db_name
        self.embedding_result_filename = embedding_result_filename
        self.candidate_items = None
        self.similarity_matrix = None
        self.test_dict = test_dict
        self.recommendation_results = None

    def generate_clean_test_dict_and_candidate_items(self):
        item_ids = self.similarity_matrix.columns[1:]
        self.test_dict, self.candidate_items = get_clean_test_dict_and_candidate_items(self.db_name, self.test_dict,
                                                                                       item_ids)

    @abstractmethod
    def generate_similarity_matrix(self):
        pass

    @abstractmethod
    def get_recommendation_result(self):
        pass

    def generate_test_essentials(self):
        self.generate_similarity_matrix()
        self.generate_clean_test_dict_and_candidate_items()

    def recommender(self):
        self.generate_test_essentials()
        self.get_recommendation_result()
