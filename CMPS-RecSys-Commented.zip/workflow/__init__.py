from utils.evaluation import evaluate


class Workflow(object):

    def __init__(self, sampling_model, embedding_model, recommender_model):
        """
        :type sampling_model: Sampling
        :type embedding_model: SkipGramModel
        :type recommender_model: Recommender
        """
        self.sampling_model = sampling_model
        self.embedding_model = embedding_model
        self.recommender_model = recommender_model

    def run(self):
        self.sampling_model.sample()
        self.sampling_model.save_train_test_dataset_to_file()

        self.embedding_model.embedding()

        self.recommender_model.recommender()

        evaluate(self.recommender_model.recommendation_results, self.recommender_model.test_dict)
