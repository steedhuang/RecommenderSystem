import subprocess
import sys
from functools import partial
from itertools import tee
from multiprocessing import Pool

from grid_evaluate import evaluate_ml100k, evaluate_ml1m
from hyperparameter_config import dimensions, walks_lengths, window_sizes, num_walks, p, q, iter_times

sys.path.append("../")
from utils.tools import send_email, load_hyparameters
from config import PROJECT_ROOT_PATH


def generate_command_deepwalk_hyparameters_table(dataset_type, trainset_index, hyparameters_tuple, process_workers):
    """
    :param dataset_type: ml-100k, ml-1m
    :param trainset_index: 1, 2, 3, 4, 5
    :param hyparameters_tuple:(dimensions, walks_length, window_size, num_walks, iter)
    :return:
    """
    dimension, walk_length, window_size, num_walk = hyparameters_tuple
    embedding_result_file_name = dataset_type + "-train-" + str(trainset_index) \
                                 + "-number-walks-" + str(num_walk) \
                                 + "-dimension-" + str(dimension) \
                                 + "-walk-length-" + str(walk_length) \
                                 + "-windows-size-" + str(window_size) \
                                 + ".deepwalkembeddings"
    command = "deepwalk --input " + PROJECT_ROOT_PATH + dataset_type + "-train-" + str(
        trainset_index) + ".edgelist --output " \
              + embedding_result_file_name \
              + " --number-walks " + str(num_walk) \
              + " --representation-size " + str(dimension) \
              + " --walk-length " + str(walk_length) \
              + " --window-size " + str(window_size) \
              + " --workers " + str(process_workers)
    return command, embedding_result_file_name


def generate_command_node2vec_hyparameters_table(dataset_type, trainset_index, hyparameters_tuple, process_workers):
    """
    :param dataset_type: ml-100k, ml-1m
    :param trainset_index: 1, 2, 3, 4, 5
    :param hyparameters_tuple:(dimensions, walks_lengths, window_sizes, num_walks, p, q, iter_times)
    :return:
    """
    dimension, walk_length, window_size, num_walk, p, q, iter_ = hyparameters_tuple
    embedding_result_file_name = dataset_type + "-train-" + str(trainset_index) \
                                 + "-number-walks-" + str(num_walk) \
                                 + "-dimension-" + str(dimension) \
                                 + "-walk-length-" + str(walk_length) \
                                 + "-windows-size-" + str(window_size) \
                                 + "-p-" + str(p) \
                                 + "-q-" + str(q) \
                                 + "-iter-" + str(iter_) \
                                 + ".node2vecembeddings"
    command = "python " + PROJECT_ROOT_PATH + "model/node2vec/src/main.py --input ../" + dataset_type + "-train-" + str(
        trainset_index) + ".edgelist --output " \
              + embedding_result_file_name \
              + " --num-walks " + str(num_walk) \
              + " --dimensions " + str(dimension) \
              + " --walk-length " + str(walk_length) \
              + " --window-size " + str(window_size) \
              + " --p " + str(p) \
              + " --q " + str(q) \
              + " --iter " + str(iter_) \
              + " --workers " + str(process_workers)
    return command, embedding_result_file_name


def deepwalk_grid_search(dataset_type, k_fold_size, top_k_size, process_workers):
    """
    :param dataset_type: ml-100k, ml-1m
    :param k_fold_size: int
    :return:
    """
    hyparameters_table = load_hyparameters(dimensions, walks_lengths, window_sizes, num_walks)
    for hyparameters_tuple in hyparameters_table:
        for trainset_index in range(1, k_fold_size + 1):
            command, embedding_result_filename = \
                generate_command_deepwalk_hyparameters_table(dataset_type,
                                                             trainset_index, hyparameters_tuple,
                                                             process_workers=process_workers)
            print command
            subprocess.call(command, shell=True)
            train_edgelist = '../' + dataset_type + "-train-" + str(trainset_index) + ".edgelist"
            test_edgelist = '../' + dataset_type + "-test-" + str(trainset_index) + ".edgelist"

            if dataset_type == "ml-1m":
                evaluate_result = evaluate_ml1m(embedding_result_filename, train_edgelist, test_edgelist,
                                                top_k_size=top_k_size)
                with open('evaluate_1m_result.csv', 'a') as the_file:
                    t = list(hyparameters_tuple)
                    t.append(trainset_index)
                    t += list(evaluate_result)
                    the_file.write(' '.join(str(i) for i in t) + '\n')
            elif dataset_type == "ml-100k":
                evaluate_result = evaluate_ml100k(embedding_result_filename, train_edgelist, test_edgelist,
                                                  top_k_size=top_k_size)
                with open('evaluate_100k_result.csv', 'a') as the_file:
                    t = list(hyparameters_tuple)
                    t.append(trainset_index)
                    t += list(evaluate_result)
                    the_file.write(' '.join(str(i) for i in t) + '\n')


def node2vec_grid_search(dataset_type, k_fold_size, top_k_size, process_workers):
    """
    :param dataset_type: ml-100k, ml-1m
    :param k_fold_size: int
    :return:
    """
    hyparameters_table, hyparameters_table2 = tee(
        load_hyparameters(dimensions, walks_lengths, window_sizes, num_walks, p, q, iter_times))
    commands = []
    for hyparameters_tuple in hyparameters_table:
        for trainset_index in range(1, k_fold_size + 1):
            command, embedding_result_filename = \
                generate_command_node2vec_hyparameters_table(dataset_type, trainset_index, hyparameters_tuple,
                                                             process_workers=process_workers)
            # print command
            commands.append(command)
            # subprocess.call(command, shell=True)

    pool = Pool()
    pool.map(partial(subprocess.call, shell=True), commands)
    pool.close()
    pool.join()

    for hyparameters_tuple in hyparameters_table2:
        for trainset_index in range(1, k_fold_size + 1):
            command, embedding_result_filename = \
                generate_command_node2vec_hyparameters_table(dataset_type, trainset_index, hyparameters_tuple,
                                                             process_workers=process_workers)
            # print command
            # subprocess.call(command, shell=True)
            train_edgelist = '../' + dataset_type + "-train-" + str(trainset_index) + ".edgelist"
            test_edgelist = '../' + dataset_type + "-test-" + str(trainset_index) + ".edgelist"

            if dataset_type == "ml-1m":
                evaluate_result = evaluate_ml1m(embedding_result_filename, train_edgelist, test_edgelist,
                                                top_k_size=top_k_size)
                with open('evaluate_1m_node2vec_result.csv', 'a') as the_file:
                    t = list(hyparameters_tuple)
                    t.append(trainset_index)
                    t += list(evaluate_result)
                    the_file.write(' '.join(str(i) for i in t) + '\n')
            elif dataset_type == "ml-100k":
                evaluate_result = evaluate_ml100k(embedding_result_filename, train_edgelist, test_edgelist,
                                                  top_k_size=top_k_size)
                with open('evaluate_100k_node2vec_result.csv', 'a') as the_file:
                    t = list(hyparameters_tuple)
                    t.append(trainset_index)
                    t += list(evaluate_result)
                    the_file.write(' '.join(str(i) for i in t) + '\n')


if __name__ == '__main__':
    # print generate_command_deepwalk_hyparameters_table(dataset_type="ml-1m", trainset_index="3",
    #                                                    hyparameters_tuple=(64, 40, 10, 10, 5), process_workers=8)
    # deepwalk_grid_search('ml-100k', k_fold_size=5, top_k_size=10, process_workers=70)
    # send_email(['727342027@qq.com'], "finish program",
    #            "deepwalk_grid_search('ml-100k', k_fold_size=5, top_k_size=10, process_workers=70)")
    node2vec_grid_search('ml-100k', k_fold_size=5, top_k_size=10, process_workers=70)
    send_email(['727342027@qq.com'], "finish program",
               "node2vec_grid_search('ml-100k', k_fold_size=5, top_k_size=10, process_workers=70)")
