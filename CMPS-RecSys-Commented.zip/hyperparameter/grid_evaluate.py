import logging

from config import ADDIDAMOUNT, LOGGER_LEVEL
from utils.edgelist import Edgelist
from utils.evaluation import evaluate
from utils.similarity import get_similarity_matrix_csv_from_user_item_embedding
from utils.top_k_recommender import top_k_rec_for_user_item_similarity_matrix

LOG_FORMAT = "%(asctime)s - %(levelname)s - %(message)s"
DATE_FORMAT = "%m/%d/%Y %H:%M:%S %p"
logging.basicConfig(format=LOG_FORMAT, datefmt=DATE_FORMAT, level=LOGGER_LEVEL)
logger = logging.getLogger("evaluate_single_one logger")


def evaluate_ml100k(embedding_file, train_edgelist, test_edgelist, top_k_size):
    similarity_df = get_similarity_matrix_csv_from_user_item_embedding(embedding_file, addidamount=ADDIDAMOUNT)

    edgelist = Edgelist('ml100k', addidamount=ADDIDAMOUNT)

    train_pair_dict = edgelist.load_pair_dict_from_edgelist(train_edgelist)
    recommendation_result = top_k_rec_for_user_item_similarity_matrix(similarity_df,
                                                                      train_pair=train_pair_dict,
                                                                      k=top_k_size)

    test_pair_dict = edgelist.load_pair_dict_from_edgelist(test_edgelist)
    evaluate_result = evaluate(recommendation_result, test_pair=test_pair_dict)
    print 'ml-100k precision, recall is ', evaluate_result
    return evaluate_result


def evaluate_ml1m(embedding_file, train_edgelist, test_edgelist, top_k_size):
    similarity_df = get_similarity_matrix_csv_from_user_item_embedding(embedding_file, addidamount=ADDIDAMOUNT)

    edgelist = Edgelist('ml1m', addidamount=ADDIDAMOUNT)

    train_pair_dict = edgelist.load_pair_dict_from_edgelist(train_edgelist)
    recommendation_result = top_k_rec_for_user_item_similarity_matrix(similarity_df,
                                                                      train_pair=train_pair_dict,
                                                                      k=top_k_size)

    test_pair_dict = edgelist.load_pair_dict_from_edgelist(test_edgelist)
    evaluate_result = evaluate(recommendation_result, test_pair=test_pair_dict)
    print 'ml-1m precision, recall is ', evaluate_result
    return evaluate_result

# if __name__ == '__main__':
#     evaluate_ml1m(embedding_file='result.embeddings', train_edgelist='ml-1m-train-1.edgelist',
#                   test_edgelist='ml-1m-test-1.edgelist', top_k_size=5)
