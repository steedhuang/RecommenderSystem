import logging
import subprocess
from functools import partial
from multiprocessing import Pool

from config import ADDIDAMOUNT, TOP_K, PROJECT_ROOT_PATH, LOGGER_LEVEL
from hyperparameter.hyperparameter_config import dimensions, walks_lengths, window_sizes, num_walks, p, q, iter_times
from utils.db import DB
from utils.evaluation import evaluate
from utils.similarity import get_similarity_matrix_csv_from_user_item_embedding, \
    get_similarity_matrix_csv_from_homogeneous_embedding
from utils.tools import load_hyparameters, get_weighed_graph_train_counter_test_dict_by_timeline, \
    get_clean_test_dict_and_candidate_items
from utils.top_k_recommender import top_k_rec_for_user_item_similarity_matrix, \
    get_item_graph_recommendation_for_user_helper

LOG_FORMAT = "%(asctime)s - %(levelname)s - %(message)s"
DATE_FORMAT = "%m/%d/%Y %H:%M:%S %p"
logging.basicConfig(format=LOG_FORMAT, datefmt=DATE_FORMAT, level=LOGGER_LEVEL)
logger = logging.getLogger("evaluate_single_one logger")


class TimeDynamicRecommendation(object):

    def __init__(self, db_name, mode):
        """
        :param db_name: ml100k, ml1m, mooc, goodbooks
        :param mode: user-item, item
        """
        if db_name not in ('ml100k', 'ml1m', 'mooc', 'goodbooks'):
            raise Exception('db_name error!')
        self.db_name = db_name

        if mode not in ('user-item', 'item'):
            raise Exception('mode error!')
        self.mode = mode

    def node2vec_multi_run(self, data_path, process_workers, weighted=False, directed=False):
        hyparameters_table = load_hyparameters(dimensions, walks_lengths, window_sizes, num_walks, p, q,
                                               iter_times)
        commands = []
        for hyparameters_tuple in hyparameters_table:
            command, _ = \
                self.generate_command_node2vec_hyper_parameters(hyparameters_tuple, data_path,
                                                                process_workers=process_workers, weighted=weighted,
                                                                directed=directed)
            commands.append(command)

        pool = Pool()
        pool.map(partial(subprocess.call, shell=True), commands)

    def evaluate_one_hyper_parameters_tuple_for_user_item_graph(self, hyparameters_tuple, test_dict,
                                                                candidate_items,
                                                                data_path):
        _, embedding_result_filename = \
            self.generate_command_node2vec_hyper_parameters(hyparameters_tuple, data_path,
                                                            process_workers=1)

        similarity_df = get_similarity_matrix_csv_from_user_item_embedding(embedding_result_filename,
                                                                           addidamount=ADDIDAMOUNT)

        recommendation_result = top_k_rec_for_user_item_similarity_matrix(similarity_df, {}, k=TOP_K,
                                                                          given_candidate_items=candidate_items)

        result = list(hyparameters_tuple)
        result += list(evaluate(recommendation_result, test_dict))
        print result
        return result

    def evaluate_one_hyper_parameters_tuple_for_item_graph(self, hyparameters_tuple, test_dict, candidate_items,
                                                           data_path):
        _, embedding_result_filename = \
            self.generate_command_node2vec_hyper_parameters(hyparameters_tuple, data_path,
                                                            process_workers=1, weighted=True)

        result = list(hyparameters_tuple)

        result += list(self.evaluate_embedding_file(embedding_result_filename, test_dict, candidate_items))
        return result

    def evaluate_embedding_file(self, embedding_result_filename, test_dict, candidate_items):
        similarity_df = get_similarity_matrix_csv_from_homogeneous_embedding(embedding_result_filename)
        recommendation_result = self.generate_recommendation_result_from_similarity_df(similarity_df, test_dict,
                                                                                       candidate_items)

        logger.info("begin evaluate recommendation results")

        evaluate_result = evaluate(recommendation_result, test_dict)
        return evaluate_result

    def generate_recommendation_result_from_similarity_df(self, similarity_df, test_dict, candidate_items):
        recommendation_result = {}

        user_list = list(test_dict.keys())
        logger.info("multiprocess get recommendation results")

        pool = Pool()
        parameters = ((self.db_name, user, similarity_df, candidate_items[user]) for user in user_list)

        pool_outputs = pool.map(get_item_graph_recommendation_for_user_helper, parameters)

        for counter, user in enumerate(user_list):
            recommendation_result[user] = pool_outputs[counter]

        pool.close()
        pool.join()

        return recommendation_result

    def node2vec_grid_evaluate(self, data_path, result_path, process_workers):

        df = DB(self.db_name).load_dataset_with_ordered_timeleine()
        _, test_dict = get_weighed_graph_train_counter_test_dict_by_timeline(df)

        hyparameters_table = load_hyparameters(dimensions, walks_lengths, window_sizes, num_walks, p, q,
                                               iter_times)
        hyparameters_table = [list(i) for i in hyparameters_table]

        if self.mode == 'user-item':
            _, embedding_result_filename = \
                self.generate_command_node2vec_hyper_parameters(hyparameters_table[0], data_path,
                                                                process_workers=process_workers)
            similarity_df = get_similarity_matrix_csv_from_user_item_embedding(embedding_result_filename,
                                                                               addidamount=ADDIDAMOUNT)
        elif self.mode == 'item':
            _, embedding_result_filename = \
                self.generate_command_node2vec_hyper_parameters(hyparameters_table[0], data_path,
                                                                process_workers=process_workers, weighted=True)
            similarity_df = get_similarity_matrix_csv_from_homogeneous_embedding(embedding_result_filename)

        item_ids = similarity_df.columns[1:]
        test_dict, candidate_items = get_clean_test_dict_and_candidate_items(self.db_name, test_dict, item_ids)

        f = open(result_path, 'w')
        for hyparameters_tuple in hyparameters_table:
            if self.mode == 'user-item':
                result = self.evaluate_one_hyper_parameters_tuple_for_user_item_graph(hyparameters_tuple, test_dict,
                                                                                      candidate_items, data_path)
            elif self.mode == 'item':
                result = self.evaluate_one_hyper_parameters_tuple_for_item_graph(hyparameters_tuple, test_dict,
                                                                                 candidate_items,
                                                                                 data_path)

            f.write(' '.join(str(i) for i in result) + '\n')

        f.close()

    def generate_command_node2vec_hyper_parameters(self, hyper_parameters_tuple, data_path, process_workers,
                                                   weighted=False, directed=False):
        dimension, walk_length, window_size, num_walk, p, q, iter_ = hyper_parameters_tuple
        embedding_result_file_name = self.db_name \
                                     + "-number-walks-" + str(num_walk) \
                                     + "-dimension-" + str(dimension) \
                                     + "-walk-length-" + str(walk_length) \
                                     + "-windows-size-" + str(window_size) \
                                     + "-p-" + str(p) \
                                     + "-q-" + str(q) \
                                     + "-iter-" + str(iter_) \
                                     + ".node2vecembeddings"
        command = "python " + PROJECT_ROOT_PATH + "model/node2vec/src/main.py --input " + data_path + self.db_name + "-train-timeline.edgelist --output " \
                  + embedding_result_file_name \
                  + " --num-walks " + str(num_walk) \
                  + " --dimensions " + str(dimension) \
                  + " --walk-length " + str(walk_length) \
                  + " --window-size " + str(window_size) \
                  + " --p " + str(p) \
                  + " --q " + str(q) \
                  + " --iter " + str(iter_) \
                  + " --workers " + str(process_workers)
        if weighted:
            command += " --weighted"
        if directed:
            command += " --directed"
        return command, embedding_result_file_name
