# for node2vec
dimensions = (64, 128, 256)
walks_lengths = (10, 20, 40, 80, 100)
window_sizes = (10, 20, 30)
num_walks = (10, 50)
p = (0.25, 1, 4)
q = (0.25, 1, 4)
# iter_times = (1, 2, 5)
iter_times = (5, )
# for deepwalk
# dimensions = (16, 32, 64, 128, 256, 512)
# walks_lengths = (5, 10, 20, 40, 80, 100)
# window_sizes = (10, 20, 30)
# num_walks = (10, 20, 30)

# for metapath2vec
# TODO